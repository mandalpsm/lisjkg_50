Academic Research Explorer - project files

FILES
- academic-research-explorer-v19.html  : the current application (open in a browser).
- original-v14-reference.html          : the original file before the Diamond Open Access
                                         Explorer edits, for reference.

ARCHITECTURE
This is a single-file, client-side web application. There is no separate backend,
database server, or build step. All HTML, CSS and JavaScript are inside the one file,
and the bibliographic dataset (27,825 records, used by "Existing dataset") is embedded
in the file, so it works offline.

The only network calls are optional and go to the public OpenAlex API
(api.openalex.org) when "Online search" is selected in the Diamond Open Access
Explorer. Those requests need an internet connection.

HOW TO RUN
Double-click academic-research-explorer-v19.html, or open it in a modern browser
(Chrome, Edge, Firefox). No installation is required.

Note: the file is about 14 MB because of the embedded dataset, so it may take a few
seconds to load.
