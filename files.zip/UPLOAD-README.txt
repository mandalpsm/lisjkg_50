PROFREEHOST UPLOAD
==================
Upload these TWO files together into the SAME folder, inside your domain's htdocs folder:

    htdocs/index.html      (621 KB)
    htdocs/dataset.bin     (4.8 MB)

Do NOT upload index-standalone-offline.html to ProFreeHost. It is 7 MB, and the host
deletes HTML/JS/text files over 1 MB. Keep it for opening locally or sharing as one file.

If you use FTP (FileZilla), send dataset.bin in BINARY mode:
Transfer > Transfer type > Binary.

Then open your site address and hard-refresh (Ctrl+F5).
